const { Builder, By, until } = require("selenium-webdriver");
const fs = require("fs");

(async function login_error() {
  let driver = await new Builder().forBrowser("chrome").build();
  try {
    // 1️⃣ Buka halaman login
    await driver.get("https://target-website.com");
    console.log("✅ Website berhasil dibuka!");

    // 2️⃣ Tunggu dan klik tombol "Sign in"
    let signInButton = await driver.wait(until.elementLocated(By.xpath("//button[contains(text(),'Sign in')]")), 5000);
    await signInButton.click();
    console.log("✅ Tombol 'Sign in' diklik!");

    // 3️⃣ Tunggu pengguna menyelesaikan reCAPTCHA
    console.log("⏳ Silakan selesaikan reCAPTCHA secara manual...");
    await driver.wait(until.elementLocated(By.id("recaptcha-anchor-label")), 60000);
    console.log("✅ reCAPTCHA telah diselesaikan!");
  } catch (error) {
    console.error("❌ Terjadi kesalahan:", error.message);

    // 🔴 Ambil screenshot saat terjadi error
    let screenshot = await driver.takeScreenshot();
    fs.writeFileSync("error_screenshot.png", screenshot, "base64");
    console.log("📸 Screenshot error telah disimpan sebagai 'error_screenshot.png'");
  } finally {
    // 🔚 Tutup browser setelah selesai
    await driver.quit();
  }
})();

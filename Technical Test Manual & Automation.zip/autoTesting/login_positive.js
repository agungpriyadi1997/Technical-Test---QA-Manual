const { Builder } = require("selenium-webdriver");

async function login_positive() {
  let driver = await new Builder().forBrowser("chrome").build();

  try {
    // Buka website
    await driver.get("https://lapor.folkatech.com");
    console.log("✅ Website berhasil dibuka!");

    const { Builder, By, until } = require("selenium-webdriver");

    async function login_positive() {
      let driver = await new Builder().forBrowser("chrome").build();

      try {
        // Buka website
        await driver.get("https://lapor.folkatech.com");

        // Tunggu hingga input email tersedia
        let emailField = await driver.wait(until.elementLocated(By.name("email")), 5000);
        await emailField.sendKeys("admin@example.com");
        console.log("✅ Email berhasil diisi!");

        // Tunggu hingga input password tersedia
        let passwordField = await driver.wait(until.elementLocated(By.id("password")), 5000);
        await passwordField.sendKeys("password");
        console.log("✅ Password berhasil diisi!");

        // Tunggu pengguna menyelesaikan reCAPTCHA secara manual
        console.log("⏳ Silakan selesaikan reCAPTCHA secara manual...");
        await driver.wait(until.elementLocated(By.id("recaptcha-anchor-label")), 60000); // Tunggu hingga 60 detik
        console.log("✅ reCAPTCHA telah diselesaikan!");

        // Tunggu tombol SIGN IN dan klik
        let signInButton = await driver.wait(until.elementLocated(By.xpath("//button[contains(text(),'SIGN IN')]")), 5000);
        await signInButton.click();
        console.log("✅ Tombol SIGN IN diklik!");

        // Tunggu beberapa detik sebelum menutup browser
        await new Promise((resolve) => setTimeout(resolve, 5000));
      } catch (error) {
        console.error("❌ Terjadi error: ", error);
      } finally {
        await driver.quit();
      }
    }

    // Jalankan fungsi
    login_positive();

    // Tunggu beberapa detik sebelum menutup browser
    await new Promise((resolve) => setTimeout(resolve, 5000));
  } catch (error) {
    console.error("❌ Terjadi error: ", error);
  } finally {
    await driver.quit();
  }
}

// Jalankan fungsi
login_positive();
